import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LocalStorageServiceService {

  constructor() { }

  public setItem(key: string, data: string): void {
    localStorage.setItem(key, data);
  }

  public getItem(key: string): any {
    return localStorage.getItem(key)!;
  }

  public removeItem(key: any): void {
    localStorage.removeItem(key);
  }

  public clear() {
    localStorage.clear();
  }
}
