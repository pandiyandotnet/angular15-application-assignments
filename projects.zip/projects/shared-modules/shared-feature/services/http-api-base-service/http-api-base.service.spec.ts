import { TestBed } from '@angular/core/testing';

import { HttpApiBaseService } from './http-api-base.service';

describe('QuizzoHttpApiBaseService', () => {
  let service: HttpApiBaseService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HttpApiBaseService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
