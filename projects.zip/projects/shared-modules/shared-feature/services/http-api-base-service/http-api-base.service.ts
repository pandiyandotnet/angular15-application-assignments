import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { retry } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class HttpApiBaseService { 
  constructor(private http: HttpClient) { }

  get(url: any) {
    return this.http.get(url);
  }

  post(url: any, postBody: any, options?: any) {
    return options ? this.http.post(url, postBody, options) : this.http.post(url, postBody);
  }

  delete(url: any) {
    return this.http.delete(url);
  }

  put(url: any, putData: any) {
    return this.http.put(url, putData);
  }

  formUrlParam(url: any, data: any) {
    let queryString: string = '';
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        if (!queryString) {
          queryString = `?${key}=${data[key]}`;
        } else {
          queryString += `&${key}=${data[key]}`;
        }
      }
    }
    return url + queryString;
  }
}
