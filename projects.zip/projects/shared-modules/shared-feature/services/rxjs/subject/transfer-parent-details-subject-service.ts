import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class TransferParentDetailsSubjectService {
    transferParentDetailsSubjectService = new Subject<any>();
    send(data: any) {
        this.transferParentDetailsSubjectService.next({ data: data });
    }

    receive(): Observable<any> {
        return this.transferParentDetailsSubjectService.asObservable();
    }
} 
 