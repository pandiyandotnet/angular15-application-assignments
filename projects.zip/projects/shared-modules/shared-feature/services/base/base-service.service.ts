import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BaseServiceService {

  constructor() { }

  public doPagination(page: any, pageSize: any, data: any, isNextSet: any = false): any {
    let dataArray: any = [];
    data.forEach((element: any, index: any) => {
      if (index < pageSize && !isNextSet)
        dataArray.push(element);
      if (page < index && index <= pageSize + page && isNextSet)
        dataArray.push(element);
    })
    return dataArray;
  }
}
