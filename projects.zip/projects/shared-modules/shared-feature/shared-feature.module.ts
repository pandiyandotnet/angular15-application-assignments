import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedFeatureRoutingModule } from './shared-feature-routing.module';
import { ToastrModule, ToastrService } from 'ngx-toastr'
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ErrorHttpInterceptor } from './interceptors/http.interceptor';
import { NgDynamicBreadcrumbModule } from 'ng-dynamic-breadcrumb';
import { registerLocaleData } from '@angular/common';
import en from '@angular/common/locales/en';

import { NZ_ICONS } from 'ng-zorro-antd/icon';
import { NZ_I18N, en_US } from 'ng-zorro-antd/i18n';
import { IconDefinition, IconModule } from '@ant-design/icons-angular';
import * as AllIcons from '@ant-design/icons-angular/icons';
registerLocaleData(en);

const antDesignIcons = AllIcons as {
  [key: string]: IconDefinition;
};
const icons: IconDefinition[] = Object.keys(antDesignIcons).map(key => antDesignIcons[key])

import { DataTablesModule } from "angular-datatables";

import { NzCardModule } from 'ng-zorro-antd/card';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { NzTimePickerModule } from 'ng-zorro-antd/time-picker';
import { NzAvatarModule } from 'ng-zorro-antd/avatar';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [
  ],
  imports: [
    FormsModule,
    CommonModule,
    SharedFeatureRoutingModule,
    ToastrModule.forRoot({
      maxOpened: 2,
      preventDuplicates: true,
      timeOut: 8000,
      closeButton: true,
      autoDismiss: true,
      newestOnTop: true
    }),
    HttpClientModule,
    NgDynamicBreadcrumbModule,
    NzCardModule,
    NzTabsModule,
    NzLayoutModule,
    NzMenuModule,
    NzSelectModule,
    NzDatePickerModule,
    NzAvatarModule,
    NzModalModule,
    NzTimePickerModule,
    NzInputModule,
    NzRadioModule,
    NzButtonModule,
    DataTablesModule,
    IconModule 
  ],
  exports: [
    FormsModule,
    HttpClientModule,
    NgDynamicBreadcrumbModule,
    NzCardModule,
    NzTabsModule,
    NzLayoutModule,
    NzMenuModule,
    NzSelectModule,
    NzDatePickerModule,
    NzAvatarModule,
    NzModalModule,
    NzTimePickerModule,
    NzInputModule,
    NzRadioModule,
    NzButtonModule,
    DataTablesModule ,
    IconModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: ErrorHttpInterceptor, multi: true },
    { provide: NZ_I18N, useValue: en_US }, { provide: NZ_ICONS, useValue: icons },
    ToastrService
  ],
})
export class SharedFeatureModule { }
