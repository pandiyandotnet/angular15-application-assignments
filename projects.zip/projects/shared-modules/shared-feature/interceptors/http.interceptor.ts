import { HttpInterceptor, HttpHandler, HttpRequest, HttpEvent, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from "@angular/core"
import { Observable, of } from "rxjs";
import { tap, catchError } from "rxjs/operators";
import { ToastrService } from 'ngx-toastr';
@Injectable()
export class ErrorHttpInterceptor implements HttpInterceptor {
    constructor(public toasterService: ToastrService) { }
    intercept(
        req: HttpRequest<any>,
        next: HttpHandler
    ): Observable<HttpEvent<any>> {
        return next.handle(req).pipe(
            tap(evt => {
                if (evt instanceof HttpResponse) {
                    // if (evt.body)
                    //this.toasterService.success(evt.body.message, "Success", { positionClass: 'toast-top-right' });
                }
            }),
            catchError((error: any) => {
                let errorMessage = '';
                if (error.error instanceof ErrorEvent) {
                    // Get client-side error
                    errorMessage = error.error.message;
                } else {
                    // Get server-side error
                    errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
                }

                this.toasterService.error(errorMessage, '', { positionClass: 'toast-bottom-right' });

                return of(error);
            }));
    }
}