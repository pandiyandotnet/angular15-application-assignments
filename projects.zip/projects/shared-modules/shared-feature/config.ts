
export const commonConfig = {
  timeInterval: 1000,
  minute: 60,
  tenminute: 10,
  fiftynine: 59,
  zero: 0
};
