import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfigurationsFeatureRoutingModule } from './configurations-feature-routing.module';
import { SharedFeatureModule } from 'projects/shared-modules/shared-feature/shared-feature.module'; 
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ParentDetailsComponent } from './components/parent-details/parent-details.component';
import { ParentRegistrationComponent } from './components/parent-registration/parent-registration.component';
import { ChildListComponent } from './components/child-list/child-list.component';
import { ChildDataManagementComponent } from './components/child-data-management/child-data-management.component';
import { ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
@NgModule({
  declarations: [
    DashboardComponent,
    ParentDetailsComponent,
    ParentRegistrationComponent,
    ChildListComponent,
    ChildDataManagementComponent
  ],
  imports: [ 
    ConfigurationsFeatureRoutingModule,
    SharedFeatureModule,
    ReactiveFormsModule, 
    CommonModule,
    NgbModule,
  ]
})
export class ConfigurationsFeatureModule { }
