export class ParentRegisterModel {
    username?: string = '';
    password?: string = '';
    gender?: string = '';
    firstname?: string = '';
    lastname?: string = '';
    email?: string = '';
    mobile?: string = '';
    emiratesid?: string = '';
}