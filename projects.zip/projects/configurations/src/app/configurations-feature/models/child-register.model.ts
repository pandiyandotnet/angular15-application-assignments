export class ChildRegisterModel {
    firstname?: string = '';
    lastname?: string = '';
    gender?: string = '';
    age: number = 0;
    photo?: string = '';
    parentid?: number = 0;
}
