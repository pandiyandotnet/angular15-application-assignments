import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChildListComponent } from './components/child-list/child-list.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ParentDetailsComponent } from './components/parent-details/parent-details.component';
import { ParentRegistrationComponent } from './components/parent-registration/parent-registration.component';

const routes: Routes = [
  {
    path: '',
    component: DashboardComponent,
    title: 'Dashboard',
    data: {
      breadcrumb: [
        {
          label: 'Dashboard',
          url: ''
        }
      ]
    },
    children: [
      {
        path: 'parentdetails', component: ParentDetailsComponent,
        data: {
          breadcrumb: [
            {
              label: 'Dashboard',
              url: ''
            },
            {
              label: 'Parent Details',
              url: ''
            } 
          ]
        },
      } ,
      {
        path: 'childrenslist', component: ChildListComponent,
        data: {
          breadcrumb: [
            {
              label: 'Dashboard',
              url: ''
            },
            {
              label: 'Child Details',
              url: ''
            } 
          ]
        },
      } 
    ]
  },
  {
    path: 'registration',
    component: ParentRegistrationComponent,
    title: 'Registration' 
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConfigurationsFeatureRoutingModule { }
