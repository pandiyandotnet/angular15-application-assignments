import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildDataManagementComponent } from './child-data-management.component';

describe('ChildDataManagementComponent', () => {
  let component: ChildDataManagementComponent;
  let fixture: ComponentFixture<ChildDataManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChildDataManagementComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChildDataManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
