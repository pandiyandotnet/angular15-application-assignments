import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { RegisterErrorConstants } from '../../constants/error/register-error-constants';
import { ChildRegisterModel } from '../../models/child-register.model';

import { RegisterService } from '../../services/service/register.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-child-data-management',
  templateUrl: './child-data-management.component.html',
  styleUrls: ['./child-data-management.component.scss']
})
export class ChildDataManagementComponent {
  ChildRegisterForm!: FormGroup;
  registerErrorConstants = RegisterErrorConstants;
  childRegisterModel!: ChildRegisterModel;
  genderValue = 'male';
  registerChildSubscription?: Subscription;
  submitted: boolean = false;
  @Input() childId: any = 0;
  @Input() parentid: any = 0;
  @Input() itemdata: any = [];
  mode: any = '';
  @Output() confirmationModalEmitter: EventEmitter<any> = new EventEmitter();
  constructor(private formBuilder: FormBuilder, private activeModal: NgbActiveModal, private router: Router, private registerService: RegisterService) { }

  ngOnInit(): void {
    this.mode = this.childId == 0 ? 'Add' : 'Edit';
    this.initRegisterForm();
  }

  initRegisterForm() {
    this.ChildRegisterForm = this.formBuilder.group({
      firstname: ['', [Validators.required]],
      lastname: ['', [Validators.required]],
      gender: [''],
      age: [0, [Validators.required]]
    });

    if (this.childId > 0)
      this.setvalue();
  }

  setvalue() {
    this.ChildRegisterForm.setValue({
      firstname: this.itemdata.firstname,
      age: this.itemdata.age,
      gender: this.itemdata.gender,
      lastname: this.itemdata.lastname
    });
    this.genderValue = this.itemdata.gender;
  }

  get getRegisterFormControl() {
    return this.ChildRegisterForm.controls;
  }

  submitForm() { 
    this.submitted = true;
    if (this.ChildRegisterForm.invalid) {
      return;
    }
    this.childRegisterModel = this.ChildRegisterForm.value;
    this.childRegisterModel.parentid = Number(this.parentid);

    if (this.childId > 0) {
      this.registerChildSubscription = this.registerService.updateChildDetails(this.childRegisterModel, this.childId).subscribe((result: any) => {
        if (result.succeeded) {
          this.activeModal.close();
          this.confirmationModalEmitter.emit();
        }
      });
    }
    else
      this.registerChildSubscription = this.registerService.registerChild(this.childRegisterModel).subscribe((result: any) => {
        if (result.succeeded) {
          this.activeModal.close();
          this.confirmationModalEmitter.emit();
        }
      });
  }

  closeModal() {
    this.activeModal.close();
  }

  ngOnDestroy() {
    this.registerChildSubscription?.unsubscribe;
  }
}
