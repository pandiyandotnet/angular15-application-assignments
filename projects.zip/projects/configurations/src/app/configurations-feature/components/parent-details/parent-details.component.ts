import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
import { RegisterService } from '../../services/service/register.service';
import { ParentRegistrationComponent } from '../parent-registration/parent-registration.component';

@Component({
  selector: 'app-parent-details',
  templateUrl: './parent-details.component.html',
  styleUrls: ['./parent-details.component.scss']
})
export class ParentDetailsComponent {
  parentdetails: any = [];
  parentid: any = 0;
  ParentDetailsSubscription?: Subscription;
  constructor(private modalService: NgbModal, private registerService: RegisterService) {

  }

  ngOnInit(): void { 
    this.parentid = localStorage.getItem("parentid");
    let data = {
      "parentid": this.parentid
    }
    this.ParentDetailsSubscription = this.registerService.getParentDetails(data).subscribe((result: any) => {
      if (result) {
        this.parentdetails = result;
      }
    });
  }

  openModal(childid: any = 0) {
    const modalRef = this.modalService.open(ParentRegistrationComponent,
      { windowClass: 'full-height-popup', size: 'md', scrollable: true, centered: true, }
    );
    modalRef.componentInstance.childId = childid;
    modalRef.componentInstance.confirmationModalEmitter.subscribe((result: any) => {
      //if (result)

    })
  }

  ngOnDestroy() {
    this.ParentDetailsSubscription?.unsubscribe;
  }
}
