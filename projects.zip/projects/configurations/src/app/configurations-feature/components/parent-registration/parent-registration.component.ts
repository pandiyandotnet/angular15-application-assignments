import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { RegisterErrorConstants } from '../../constants/error/register-error-constants';
import { ParentRegisterModel } from '../../models/parent-register.model';
import { RegisterService } from '../../services/service/register.service';

@Component({
  selector: 'app-parent-registration',
  templateUrl: './parent-registration.component.html',
  styleUrls: ['./parent-registration.component.scss']
})
export class ParentRegistrationComponent {
  RegisterForm!: FormGroup;
  registerErrorConstants = RegisterErrorConstants;
  parentRegisterModel!: ParentRegisterModel;
  genderValue = 'male';
  registerParentSubscription?: Subscription;
  submitted: boolean = false;

  constructor(public toasterService: ToastrService,private formBuilder: FormBuilder, private router: Router, private registerService: RegisterService) { }

  ngOnInit(): void {
    this.initRegisterForm();
  }

  initRegisterForm() {
    this.RegisterForm = this.formBuilder.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]],
      gender: [''],
      firstname: ['', [Validators.required]],
      lastname: ['', [Validators.required]],
      email: ['', [Validators.required]],
      mobile: ['', [Validators.required]],
      emiratesid: ['', [Validators.required]]
    });
  }

  get getRegisterFormControl() {
    return this.RegisterForm.controls;
  }

  submitForm() { 
    this.submitted = true;
    if (this.RegisterForm.invalid) {
      return;
    }
    this.parentRegisterModel = this.RegisterForm.value;
    this.registerParentSubscription = this.registerService.registerParent(this.parentRegisterModel).subscribe((result: any) => {
      if (result.succeeded) {
        this.router.navigate(['/']);
        this.toasterService.success(result.message, "Success", { positionClass: 'toast-top-right' });
      }
    });
  }

  ngOnDestroy() {
    this.registerParentSubscription?.unsubscribe;
  }
}
