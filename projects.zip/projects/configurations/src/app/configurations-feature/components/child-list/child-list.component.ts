import { Component, ViewChild } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DataTableDirective } from 'angular-datatables';
import { data } from 'jquery';
import { Subject, Subscription } from 'rxjs';
import { RegisterService } from '../../services/service/register.service';
import { ChildDataManagementComponent } from '../child-data-management/child-data-management.component';
@Component({
  selector: 'app-child-list',
  templateUrl: './child-list.component.html',
  styleUrls: ['./child-list.component.scss']
})
export class ChildListComponent {
  @ViewChild(DataTableDirective, { static: false })
  dtElement!: DataTableDirective;

  dtTrigger: any = new Subject();
  dtOptions: any = {};
  parentid: any = 0;
  ChildDetailsSubscription?: Subscription;
  childdetails: any = [];
  constructor(private modalService: NgbModal, private registerService: RegisterService) {
  }
  ngOnInit(): void {
    this.parentid = localStorage.getItem("parentid");
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      processing: true,
      dom: 'Blfrtip',
      buttons: [
        'copy',
        'csv',
        'excel',
        'pdf',
        {
          extend: 'print',
          text: 'print',
          title: 'Childrens List',
          autoPrint: true,
          customize: function (win: any) {
            $(win.document.body)
              .css('font-size', '10pt');

            $(win.document.body).find('table')
              .addClass('compact')
              .css('font-size', 'inherit');
          }
        },
        'colvis'
      ]
    };
    this.loadChildrensData();
  }

  loadChildrensData() {
    this.ChildDetailsSubscription = this.registerService.getChildDetails(this.parentid).subscribe((result: any) => { 
      if (result) {
        this.childdetails = result;
      }
    });
  }

  openModal(childid: any = 0, item: any = []) {
    const modalRef = this.modalService.open(ChildDataManagementComponent,
      { windowClass: 'full-height-popup', size: 'md', scrollable: true, centered: true, }
    );
    modalRef.componentInstance.childId = childid;
    modalRef.componentInstance.parentid = this.parentid;
    modalRef.componentInstance.itemdata = item;
    modalRef.componentInstance.confirmationModalEmitter.subscribe((result: any) => { 
      //if (result)
      this.loadChildrensData();
    })
  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();
      // Call the dtTrigger to rerender again
      this.dtTrigger.next();
    });
  }

  deleteChildrensData(id:any) {
    this.ChildDetailsSubscription = this.registerService.deleteChildDetails(id).subscribe((result: any) => {
      if (result) {
        this.loadChildrensData();
      }
    });
  }

  ngOnDestroy() {
    this.dtTrigger.unsubscribe();
    this.ChildDetailsSubscription?.unsubscribe;
  }
}
