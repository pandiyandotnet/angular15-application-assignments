import { Injectable } from '@angular/core';
import { environment } from 'projects/configurations/src/environments/environment';
import { HttpApiBaseService } from 'projects/shared-modules/shared-feature/services/http-api-base-service/http-api-base.service';
import { RegisterApiConstants } from '../../constants/api/register-api-constants';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {
  private registerApiConstants = RegisterApiConstants;
  private baseUrl = environment.apiUrl;

  constructor(private httpApiBaseService: HttpApiBaseService) { }

  registerParent(data: any) {
    return this.httpApiBaseService.post(`${this.baseUrl}${this.registerApiConstants.parent}`, data, false);
  }

  registerChild(data: any) {
    return this.httpApiBaseService.post(`${this.baseUrl}${this.registerApiConstants.child}`, data, false);
  }

  updateChildDetails(data: any, id: any) {
    return this.httpApiBaseService.put(`${this.baseUrl}${this.registerApiConstants.child}/${id}`, data);
  }

  deleteChildDetails(id: any) {
    return this.httpApiBaseService.put(`${this.baseUrl}${this.registerApiConstants.childDelete}/${id}`, {});
  }

  getParentDetails(data: any) {
    return this.httpApiBaseService.get(`${this.baseUrl}${this.registerApiConstants.parent}/${data.parentid}`);
  }

  getChildDetails(data: any) {
    return this.httpApiBaseService.get(`${this.baseUrl}${this.registerApiConstants.child}/${data}`);
  }
}
