export enum RequestType {
    FileUpload = 0,
    PlainText = 1,
    QuestionPool = 2
}

export enum QuizStatus {
    Draft = 0,
    Processing = 1,
    Completed = 2,
    Assigned = 3
}

export enum enumStepper {
    Chapter = 0,
    CreateQuiz = 1,
    EditQuiz = 2,
    PublishQuiz = 3,
    SuccessQuiz = 4
}

export enum Complexity {
    easy = 0,
    medium = 1,
    hard = 2,
}

export enum QuestionType {
    mcq = 0,
    true_false = 1,
    fill_up = 2
}

export enum QuestionPoolListingStatus {
    validated = 0,
    delisted = 1,
    none = 2
}

export enum BaseType {
    QuestionType = 0,
    Complexity = 1,
    Status = 2,
    bloomTaxonomyArray = 3,
    correctAnswer = 4,
    StatusFilter = 5,
    QuizStatus = 6
}

export enum BloomTaxonomy {
    remember = 0,
    understand = 1,
    apply = 2,
    analyze = 3,
    evaluate = 4,
    create = 5
}

export enum QuestionValidationEnum {
    questiontype = 0,
    complexity = 1,
    status = 2,
}

export enum PrimaryFilterEnum {
    Curriculum = 0,
    Grade = 1,
    Subject = 2,
    Chapter = 3,
}

export enum Persona {
    Teacher = 0,
    Student = 1,
}

export enum enumBoolean {
    true = 'true',
    false = 'false',
}