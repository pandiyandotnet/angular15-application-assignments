export const RegisterApiConstants = {
    parent: 'ParentsDetails',
    child: 'ChildrenDetails',
    childDelete: 'ChildrenDetails/Delete'
}