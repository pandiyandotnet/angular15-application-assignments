export const RegisterErrorConstants = {
    requiredUsername: 'Username is required',
    requiredPassword: 'Password is required',
    requiredFirstName: 'First Name is required',
    requiredLastName: 'Last Name is required',
    requiredEmail: 'Email is required',
    requiredMobileNumber: 'Mobile Number is required',
    requiredEmiratesId: 'EmiratesId is required',
    requiredAge: 'Age is required' 
}