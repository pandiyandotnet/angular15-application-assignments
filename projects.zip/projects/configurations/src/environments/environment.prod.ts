export const environment = {
  production: true,
  apiUrl: '{__#apiquizzobaseurl#__}/v1/'
};
