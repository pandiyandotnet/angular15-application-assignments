import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { TransferParentDetailsSubjectService } from 'projects/shared-modules/shared-feature/services/rxjs/subject/transfer-parent-details-subject-service';
import { Subscription } from 'rxjs';
import { LoginErrorConstants } from '../../constants/error/login-error-constants';
import { LoginService } from '../../service/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  LoginForm!: FormGroup;
  loginErrorConstants = LoginErrorConstants;

  submitted: boolean = false;
  loginSubscription?: Subscription;
  constructor(private transferParentDetailsSubjectService: TransferParentDetailsSubjectService, public toasterService: ToastrService, private formBuilder: FormBuilder, private router: Router, private loginService: LoginService) { }

  ngOnInit(): void {
    this.LoginForm = this.formBuilder.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]]
    });
  }

  get getLoginFormControl() {
    return this.LoginForm.controls;
  }

  submitForm() {
    this.submitted = true;
    if (this.LoginForm.invalid) {
      return;
    }
    let data = {
      "username": this.LoginForm.get('username')?.value,
      "password": this.LoginForm.get('password')?.value
    }

    this.loginSubscription = this.loginService.login(data).subscribe((result: any) => { 
      if (result != 0) { 
        localStorage.setItem("parentid", result);
        this.router.navigate(['/configurations/parentdetails']);
      }
      else
        this.toasterService.error('Unauthorized user, please contact the administrator.', '', { positionClass: 'toast-bottom-right' });
    });
  }

  ngOnDestroy() {
    this.loginSubscription?.unsubscribe;
  }
}
