import { Injectable } from '@angular/core';
import { HttpApiBaseService } from 'projects/shared-modules/shared-feature/services/http-api-base-service/http-api-base.service';
import { environment } from 'projects/shell/src/environments/environment';
import { LoginApiConstants } from '../constants/api/login-api-constants';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private loginApiConstants = LoginApiConstants;
  private baseUrl = environment.apiUrl;

  constructor(private httpApiBaseService: HttpApiBaseService) { }

  login(data: any) {
    return this.httpApiBaseService.get(`${this.baseUrl}${this.loginApiConstants.login}/${data.username}/${data.password}`);
  } 
}
