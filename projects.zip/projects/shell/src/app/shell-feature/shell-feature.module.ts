import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ShellFeatureRoutingModule } from './shell-feature-routing.module'; 
@NgModule({
  declarations: [
    
  ],
  imports: [
    CommonModule,
    ShellFeatureRoutingModule
  ]
})
export class ShellFeatureModule { }
