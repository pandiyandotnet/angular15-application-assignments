export const LoginErrorConstants = {
    requiredUsername: 'Username is required',
    requiredPassword: 'Password is required',  
}