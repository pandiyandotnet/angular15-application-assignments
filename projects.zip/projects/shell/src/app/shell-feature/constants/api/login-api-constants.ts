export const LoginApiConstants = {
    login: 'ParentsDetails' 
}