import { loadRemoteModule } from '@angular-architects/module-federation';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth/auth.guard';
import { LoginComponent } from './shell-feature/components/login/login.component';
const data = require("../appsettings/appsettings.json");
const webpackConfig = data.webpackConfig;
const routes: Routes = [
  {
    path: '',
    component: LoginComponent,
    title: 'Login' 
  },
  {
    path: 'configurations',
    loadChildren: () => loadRemoteModule(webpackConfig.configurations).then((m: any) => m.ConfigurationsFeatureModule),
    canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
