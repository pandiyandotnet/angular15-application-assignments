CREATE DATABASE EDB

USE EDB

------Tables
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TABLE dbo.ParentDetails (
  parentid  BIGINT	NOT NULL    IDENTITY(1,1)    PRIMARY KEY,
  username  NVARCHAR(100)	NOT NULL DEFAULT '',
  password  NVARCHAR(30)	NOT NULL DEFAULT '',
  gender	NVARCHAR(10)	NOT NULL DEFAULT '',
  firstname NVARCHAR(200)	NOT NULL DEFAULT '',
  lastname  NVARCHAR(200)	NOT NULL DEFAULT '',
  email		NVARCHAR(200)	NOT NULL DEFAULT '',
  mobile	NVARCHAR(30)	NOT NULL DEFAULT '',
  emiratesid NVARCHAR(50)	NOT NULL DEFAULT '',
  isdeleted 	INT			NOT NULL DEFAULT 0,
  createdon DATETIME NOT NULL DEFAULT '',
  createdby NVARCHAR(50) NOT NULL DEFAULT '',
  modifiedon DATETIME NOT NULL DEFAULT '',
  modifiedby NVARCHAR(50) NOT NULL DEFAULT ''
);

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TABLE dbo.ChildrenDetails (
  childid   BIGINT	NOT NULL    IDENTITY(1,1)    PRIMARY KEY,   
  parentid  BIGINT			NOT NULL DEFAULT 0,
  firstname NVARCHAR(200)	NOT NULL DEFAULT '',
  lastname  NVARCHAR(200)	NOT NULL DEFAULT '',
  gender	NVARCHAR(10)	NOT NULL DEFAULT '',
  age		INT				NOT NULL DEFAULT 0,
  url		NVARCHAR(MAX)	NOT NULL DEFAULT '',
  isdeleted 	INT			NOT NULL DEFAULT 0,
  createdon DATETIME		NOT NULL DEFAULT '',
  createdby NVARCHAR(50)	NOT NULL DEFAULT '',
  modifiedon DATETIME		NOT NULL DEFAULT '',
  modifiedby NVARCHAR(50)	NOT NULL DEFAULT '',
  CONSTRAINT fk_parentid    FOREIGN KEY (parentid) REFERENCES dbo.ParentDetails(parentid)
);


---Stored Procedures 
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[uspParentsDataManagement]
	  @parentid		BIGINT=0
	, @username		NVARCHAR(100)=''
	, @password		NVARCHAR(30)=''
	, @gender		NVARCHAR(10)=''
	, @firstname	NVARCHAR(200)=''
	, @lastname		NVARCHAR(200)=''
	, @email		NVARCHAR(200)=''
	, @mobile		NVARCHAR(30)=''
	, @emiratesid	NVARCHAR(30)=''
	, @userid		BIGINT=0
	, @action		INT=0
AS
BEGIN

	IF (@action=2)
		UPDATE dbo.ParentDetails SET isdeleted=1 WHERE parentid=@parentid 
	ELSE IF(@action=1)
		UPDATE [dbo].[ParentDetails]
		SET [username] = @username			,[password] = @password	
			,[gender] = @gender				,[firstname] = @firstname
			,[lastname] = @lastname			,[email] = @email
			,[mobile] = @mobile				,[emiratesid] = @emiratesid
			,[modifiedon] = GETDATE()		,[modifiedby] = @userid
		WHERE parentid=@parentid 
	ELSE
		INSERT INTO [dbo].[ParentDetails]
           ([username]				,[password]
           ,[gender]				,[firstname]
           ,[lastname]				,[email]
           ,[mobile]				,[emiratesid]
           ,[createdon])
		VALUES
           (@username
           ,@password	
           ,@gender	
           , @firstname
           ,@lastname
           ,@email
           ,@mobile
           ,@emiratesid 
           ,GETDATE())
END
 
  
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[uspChildrenDataManagement]
	  @childid		BIGINT=0
	, @parentid		BIGINT=0
	, @gender		NVARCHAR(10)='' 
	, @firstname	NVARCHAR(200)=''
	, @lastname		NVARCHAR(200)=''
	, @age			NVARCHAR(200)=''
	, @action		INT=0
	, @url			NVARCHAR(MAX)=''	 
	, @userid		BIGINT=0 
AS
BEGIN

	IF (@action=2)
		UPDATE dbo.[ChildrenDetails] SET isdeleted=1 WHERE childid=@childid 
	ELSE IF(@action=1)
		UPDATE [dbo].[ChildrenDetails]
		   SET  [firstname] = @firstname
			  ,[lastname] = @lastname
			  ,[gender] = @gender
			  ,[age] = @age
			  ,[url] = @url 
			  ,[modifiedon] = GETDATE()
			  ,[modifiedby] = @userid
		WHERE childid=@childid 
	ELSE
		INSERT INTO [dbo].[ChildrenDetails]
           ([parentid]				,[firstname]
           ,[lastname]				,[gender]
           ,[age]					,[url]
           ,[createdby]             ,[createdon])
		VALUES
           (@parentid
           ,@firstname
           ,@lastname
           ,@gender
           ,@age
           ,@url 
           ,@userid
           ,GETDATE())
END

------------------------------------------------

CREATE PROCEDURE [dbo].[uspLogin] 
	@username		NVARCHAR(100)=''
	, @password		NVARCHAR(30)=''
AS
BEGIN 
	SET NOCOUNT ON; 
	IF EXISTS(SELECT [username] FROM dbo.ParentDetails WHERE [username] = @username AND [password]=@password AND [isdeleted]=0) 
			SELECT [parentid] AS Result	 
					 FROM dbo.ParentDetails 
			WHERE [username] = @username AND [password]=@password AND [isdeleted]=0
	ELSE  
			SELECT 0 as Result
	SET NOCOUNT OFF; 
END

------------------------------------------------
CREATE PROCEDURE [dbo].[uspGetParentDetails] 
	@parentid		NVARCHAR(100)='' 
AS
BEGIN 
	SET NOCOUNT ON; 
 
			SELECT [parentid]	,[username]	,[password] ,[gender]  ,[firstname]
					,[lastname] ,[email]    ,[mobile]   ,[emiratesid]
					 FROM dbo.ParentDetails 
			WHERE parentid=@parentid AND [isdeleted]=0
	 
	SET NOCOUNT OFF; 
END

------------------------------------------------

CREATE PROCEDURE [dbo].[uspGetChildrenDetails] 
	@parentid		BIGINT=0
AS
BEGIN 
	SET NOCOUNT ON; 

	SELECT [childid]
      ,[parentid]
      ,[firstname]
      ,[lastname]
      ,[gender]
      ,[age]
      ,[url] 
      ,[createdon]
      ,[createdby]
      ,[modifiedon]
      ,[modifiedby]
	FROM [EDB].[dbo].[ChildrenDetails] where [parentid]=@parentid AND [isdeleted]=0

	SET NOCOUNT OFF;  
END
