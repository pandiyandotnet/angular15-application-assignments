﻿using System;
using MediatR;

namespace EDBDomain.SeedWork
{
    public interface IDomainEvent : INotification
    {
        DateTime OccurredOn { get; }
    }
}
