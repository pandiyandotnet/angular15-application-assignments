﻿
using EDBDomain.SeedWork;

namespace EDBDomain.AggregateModels.ParentsDetailAggregate
{
    public class ParentsDetail : IAggregateRoot
    {  
        public string username { get; set; }
        public string password { get; set; }
        public string gender { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string email { get; set; }
        public string mobile { get; set; }
        public string emiratesid { get; set; }
    }
} 