﻿
using EDBDomain.SeedWork;

namespace EDBDomain.AggregateModels.ChildrenDetailAggregate
{
    public class ChildrenDetail : IAggregateRoot
    {
        public Int64 parentid { get; set; }
        public Int64 childid { get; set; }
        public string gender { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public int age { get; set; }
    }
} 