﻿

using EDBDomain.AggregateModels.ParentsDetailAggregate;
using EDBDomain.SeedWork;

namespace EDBDomain.IRepositories
{
    public interface IParentsDetailsRepository : IRepository<ParentsDetail>
    {
        ParentsDetail Add(ParentsDetail parentsDetail);
        ParentsDetail Update(ParentsDetail parentsDetail);
        ParentsDetail Delete(ParentsDetail parentsDetail);
    }
}