﻿

using EDBDomain.AggregateModels.ChildrenDetailAggregate;
using EDBDomain.SeedWork;

namespace EDBDomain.IRepositories
{
    public interface IChildrenDetailsRepository : IRepository<ChildrenDetail>
    {
        ChildrenDetail Add(ChildrenDetail childrenDetail);
        ChildrenDetail Update(ChildrenDetail childrenDetail);
        ChildrenDetail Delete(ChildrenDetail childrenDetail);
    }
}