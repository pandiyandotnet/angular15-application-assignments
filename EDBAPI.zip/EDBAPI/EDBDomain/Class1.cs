﻿namespace EDBDomain
{
    public class Class1
    {

    }
}