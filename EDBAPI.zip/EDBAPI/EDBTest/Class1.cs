﻿namespace EDBTest
{
    public class Class1
    {

    }
}