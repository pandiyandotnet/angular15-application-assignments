﻿using EDBApplication.AggregateModels;
using EDBApplication.Responses;
using MediatR; 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDBApplication.Queries.GetParentDetails
{
    public class GetParentDetailsQuery : IRequest<ParentsDetailDto>
    {
        public int parentid { get; set; } 
    }
}
