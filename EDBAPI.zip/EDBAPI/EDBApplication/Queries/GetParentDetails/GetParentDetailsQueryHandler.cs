﻿using AutoMapper;
using EDBApplication.AggregateModels;
using EDBApplication.Responses;
using EDBDomain.AggregateModels.ParentsDetailAggregate;
using EDBInfrastructure.Database;
using MediatR;
using System.Data.SqlClient;
using System.Data;
using System.Net;
using Microsoft.AspNetCore.Http;

namespace EDBApplication.Queries.GetParentDetails
{
    public class GetParentDetailsQueryHandler : IRequestHandler<GetParentDetailsQuery, ParentsDetailDto>
    {
        public readonly ISqlConnectionFactory _sqlConnectionFactory;
        public GetParentDetailsQueryHandler(
            ISqlConnectionFactory sqlConnectionFactory)
        {
            _sqlConnectionFactory = sqlConnectionFactory;
        }

        public async Task<ParentsDetailDto> Handle(GetParentDetailsQuery request, CancellationToken cancellationToken)
        {
            var response = new ParentsDetailDto();
            using (var _conn = this._sqlConnectionFactory.GetOpenConnection())
            {
                using (var tr = _conn.BeginTransaction())
                {
                    try
                    {
                        using (SqlCommand command = new SqlCommand())
                        {
                            command.Connection = _conn;
                            command.CommandType = CommandType.StoredProcedure;
                            command.CommandText = "uspGetParentDetails";
                            command.Transaction = tr;
                            command.Parameters.Add("@parentid", SqlDbType.NVarChar).Value = request.parentid; 
                            DataTable dt = new DataTable();

                            using (SqlDataAdapter dataAdapter = new SqlDataAdapter(command))
                            {
                                dataAdapter.SelectCommand = command;
                                dataAdapter.Fill(dt);
                            }

                            foreach (DataRow row in dt.Rows)
                            {
                                response  = CreateFromSqlDataReader(row);
                            }
                        }
                        tr.Commit();
                        return response;
                    }
                    catch (Exception ex)
                    {
                        tr.Rollback();
                        return response;
                    }
                }
            }
        }

        public ParentsDetailDto CreateFromSqlDataReader(DataRow row)
        {
            var parentsDetail = new ParentsDetailDto()
            {
                parentid = Convert.ToInt64(row["parentid"]),
                username = Convert.ToString(row["username"]),
                password = row["password"].ToString(),
                gender = row["gender"].ToString(),
                firstname = row["firstname"].ToString(),
                lastname = row["lastname"].ToString(),
                email = row["email"].ToString(),
                mobile = row["mobile"].ToString(),
                emiratesid = row["emiratesid"].ToString(),
            };
            return parentsDetail;
        }
    }
}