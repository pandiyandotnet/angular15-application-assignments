﻿using AutoMapper;
using EDBApplication.AggregateModels;
using EDBApplication.Responses;
using EDBDomain.AggregateModels.ParentsDetailAggregate;
using EDBInfrastructure.Database;
using MediatR;
using System.Data.SqlClient;
using System.Data;
using System.Net;
using Microsoft.AspNetCore.Http;

namespace EDBApplication.Queries.GetLogin
{
    public class GetLoginQueryHandler : IRequestHandler<GetLoginQuery, int>
    {
        public readonly ISqlConnectionFactory _sqlConnectionFactory;
        public GetLoginQueryHandler(
            ISqlConnectionFactory sqlConnectionFactory)
        {
            _sqlConnectionFactory = sqlConnectionFactory;
        }

        public async Task<int> Handle(GetLoginQuery request, CancellationToken cancellationToken)
        {
            var response = 0;
            using (var _conn = this._sqlConnectionFactory.GetOpenConnection())
            {
                using (var tr = _conn.BeginTransaction())
                {
                    try
                    {
                        using (SqlCommand command = new SqlCommand())
                        {
                            command.Connection = _conn;
                            command.CommandType = CommandType.StoredProcedure;
                            command.CommandText = "uspLogin";
                            command.Transaction = tr;
                            command.Parameters.Add("@username", SqlDbType.NVarChar).Value = request.username;
                            command.Parameters.Add("@password", SqlDbType.NVarChar).Value = request.password;
                            DataTable dt = new DataTable();

                            using (SqlDataAdapter dataAdapter = new SqlDataAdapter(command))
                            {
                                dataAdapter.SelectCommand = command;
                                dataAdapter.Fill(dt);
                            }

                            foreach (DataRow row in dt.Rows)
                            {
                                response = Convert.ToInt32(row[0]);
                            }
                        }
                        tr.Commit();
                        return response;
                    }
                    catch (Exception ex)
                    {
                        tr.Rollback();
                        return response;
                    }
                }
            }
        }
    }
}