﻿using EDBApplication.AggregateModels;
using EDBApplication.Responses;
using MediatR; 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDBApplication.Queries.GetLogin
{
    public class GetLoginQuery : IRequest<int>
    {
        public string username { get; set; }

        public string password { get; set; }
    }
}
