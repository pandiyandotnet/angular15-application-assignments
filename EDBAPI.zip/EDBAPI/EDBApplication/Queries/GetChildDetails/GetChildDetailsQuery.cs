﻿using EDBApplication.AggregateModels;
using EDBApplication.Responses;
using MediatR; 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDBApplication.Queries.GetChildDetails
{
    public class GetChildDetailsQuery : IRequest<List<ChildDetailDto>>
    {
        public int parentid { get; set; } 
    }
}
