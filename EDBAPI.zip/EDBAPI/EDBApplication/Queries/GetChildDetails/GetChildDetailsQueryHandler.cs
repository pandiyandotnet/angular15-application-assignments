﻿using AutoMapper;
using EDBApplication.AggregateModels;
using EDBApplication.Responses;
using EDBDomain.AggregateModels.ParentsDetailAggregate;
using EDBInfrastructure.Database;
using MediatR;
using System.Data.SqlClient;
using System.Data;
using System.Net;
using Microsoft.AspNetCore.Http;

namespace EDBApplication.Queries.GetChildDetails
{
    public class GetChildDetailsQueryHandler : IRequestHandler<GetChildDetailsQuery, List<ChildDetailDto>>
    {
        public readonly ISqlConnectionFactory _sqlConnectionFactory;
        public GetChildDetailsQueryHandler(
            ISqlConnectionFactory sqlConnectionFactory)
        {
            _sqlConnectionFactory = sqlConnectionFactory;
        }

        public async Task<List<ChildDetailDto>> Handle(GetChildDetailsQuery request, CancellationToken cancellationToken)
        {
            var response = new List<ChildDetailDto>();
            using (var _conn = this._sqlConnectionFactory.GetOpenConnection())
            {
                using (var tr = _conn.BeginTransaction())
                {
                    try
                    {
                        using (SqlCommand command = new SqlCommand())
                        {
                            command.Connection = _conn;
                            command.CommandType = CommandType.StoredProcedure;
                            command.CommandText = "uspGetChildrenDetails";
                            command.Transaction = tr;
                            command.Parameters.Add("@parentid", SqlDbType.NVarChar).Value = request.parentid; 
                            DataTable dt = new DataTable();

                            using (SqlDataAdapter dataAdapter = new SqlDataAdapter(command))
                            {
                                dataAdapter.SelectCommand = command;
                                dataAdapter.Fill(dt);
                            }

                            foreach (DataRow row in dt.Rows)
                            {
                                response.Add(CreateFromSqlDataReader(row));
                            }
                        }
                        tr.Commit();
                        return response;
                    }
                    catch (Exception ex)
                    {
                        tr.Rollback();
                        return response;
                    }
                }
            }
        }

        public ChildDetailDto CreateFromSqlDataReader(DataRow row)
        {
            var parentsDetail = new ChildDetailDto()
            {
                parentid = Convert.ToInt64(row["parentid"]), 
                gender = row["gender"].ToString(),
                firstname = row["firstname"].ToString(),
                lastname = row["lastname"].ToString(),
                childid = Convert.ToInt32(row["childid"]),
                age = Convert.ToInt32(row["age"]) 
            };
            return parentsDetail;
        }
    }
}