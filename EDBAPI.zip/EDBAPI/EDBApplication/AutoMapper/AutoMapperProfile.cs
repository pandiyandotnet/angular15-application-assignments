﻿using AutoMapper;
using EDBApplication.Commands.ChildrenDetails;
using EDBApplication.Commands.ParentsDetails;
using EDBDomain.AggregateModels.ChildrenDetailAggregate;
using EDBDomain.AggregateModels.ParentsDetailAggregate;

namespace EDBApplication.AutoMapper
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<CreateParentsDetailsCommand, ParentsDetail>()
                .ForMember(dest => dest.username, opt => opt.MapFrom(src => src.username))
                .ForMember(dest => dest.password, opt => opt.MapFrom(src => src.password))
                .ForMember(dest => dest.firstname, opt => opt.MapFrom(src => src.firstname))
                .ForMember(dest => dest.lastname, opt => opt.MapFrom(src => src.lastname))
                .ForMember(dest => dest.gender, opt => opt.MapFrom(src => src.gender))
                .ForMember(dest => dest.email, opt => opt.MapFrom(src => src.email))
                .ForMember(dest => dest.mobile, opt => opt.MapFrom(src => src.mobile))
                .ForMember(dest => dest.emiratesid, opt => opt.MapFrom(src => src.emiratesid));

            CreateMap<CreateChildrenDetailsCommand, ChildrenDetail>()
                .ForMember(dest => dest.parentid, opt => opt.MapFrom(src => src.parentid))
                .ForMember(dest => dest.age, opt => opt.MapFrom(src => src.age))
                .ForMember(dest => dest.firstname, opt => opt.MapFrom(src => src.firstname))
                .ForMember(dest => dest.lastname, opt => opt.MapFrom(src => src.lastname))
                .ForMember(dest => dest.gender, opt => opt.MapFrom(src => src.gender));

            CreateMap<UpdateChildrenDetailsCommand, ChildrenDetail>()
               .ForMember(dest => dest.parentid, opt => opt.MapFrom(src => src.parentid))
                .ForMember(dest => dest.childid, opt => opt.MapFrom(src => src.childid))
               .ForMember(dest => dest.age, opt => opt.MapFrom(src => src.age))
               .ForMember(dest => dest.firstname, opt => opt.MapFrom(src => src.firstname))
               .ForMember(dest => dest.lastname, opt => opt.MapFrom(src => src.lastname))
               .ForMember(dest => dest.gender, opt => opt.MapFrom(src => src.gender));

            CreateMap<DeleteChildrenDetailsCommand, ChildrenDetail>()
             .ForMember(dest => dest.childid, opt => opt.MapFrom(src => src.childid));
            
        }
    }
}
