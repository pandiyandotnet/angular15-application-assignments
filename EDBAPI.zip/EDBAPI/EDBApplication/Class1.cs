﻿namespace EDBApplication
{
    public class Class1
    {

    }
}