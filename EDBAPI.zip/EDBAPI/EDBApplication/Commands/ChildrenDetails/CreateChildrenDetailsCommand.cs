﻿using EDBApplication.Responses;
using MediatR; 
namespace EDBApplication.Commands.ChildrenDetails
{
    public class CreateChildrenDetailsCommand : IRequest<Response<string>>
    {
        public Int64 childid { get; set; }
        public Int64 parentid { get; set; }
        public string gender { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public int age { get; set; } 
    }
}
