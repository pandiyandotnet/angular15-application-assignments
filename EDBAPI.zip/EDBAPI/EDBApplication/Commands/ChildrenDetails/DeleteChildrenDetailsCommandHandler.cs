﻿using AutoMapper;
using EDBApplication.Responses;
using EDBDomain.AggregateModels.ChildrenDetailAggregate;
using EDBDomain.IRepositories;
using MediatR; 
using System.Net;

namespace EDBApplication.Commands.ChildrenDetails
{
    public class DeleteChildrenDetailsCommandHandler : IRequestHandler<DeleteChildrenDetailsCommand, Response<string>>
    {
        private readonly IChildrenDetailsRepository _childrenDetailsRepository;
        private readonly IMapper _mapper;
        public DeleteChildrenDetailsCommandHandler(IChildrenDetailsRepository childrenDetailsRepository,
            IMapper mapper)
        {
            _childrenDetailsRepository = childrenDetailsRepository;
            _mapper = mapper;
        }
        public async Task<Response<string>> Handle(DeleteChildrenDetailsCommand request, CancellationToken cancellationToken)
        {
            var response = new Response<string>();
            try
            {
                var _request = _mapper.Map<ChildrenDetail>(request);
                this._childrenDetailsRepository.Delete(_request);
                await this._childrenDetailsRepository.UnitOfWork.DeleteRecordAsync(cancellationToken);
                return new Response<string>()
                {
                    Succeeded = true,
                    Message = "Children Details Deleted Successfully"
                };
            }
            catch (Exception ex)
            {
                response.Succeeded = false;
                response.StatusCode = (int)HttpStatusCode.BadRequest;
                response.Message = "Error";
            }
            return response;
        }
    }
}
