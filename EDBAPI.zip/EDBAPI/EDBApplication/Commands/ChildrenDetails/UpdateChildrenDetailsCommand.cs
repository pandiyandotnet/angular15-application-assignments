﻿
using EDBApplication.Responses;
using EDBDomain.AggregateModels.ParentsDetailAggregate;
using MediatR;
using System.Text.Json.Serialization;
 

namespace EDBApplication.Commands.ChildrenDetails
{
    public class UpdateChildrenDetailsCommand : IRequest<Response<string>>
    {
        public Int64 parentid { get; set; }
        public Int64 childid { get; set; }
        public string gender { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public int age { get; set; }
    }
}
