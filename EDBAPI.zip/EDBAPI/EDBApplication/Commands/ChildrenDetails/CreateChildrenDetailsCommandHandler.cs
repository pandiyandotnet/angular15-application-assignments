﻿using AutoMapper;
using EDBApplication.Commands.ChildrenDetails;
using EDBApplication.Responses;
using EDBDomain.AggregateModels.ChildrenDetailAggregate;
using EDBDomain.AggregateModels.ParentsDetailAggregate;
using EDBDomain.IRepositories;
using MediatR; 
using System.Globalization;
using System.Net;

namespace EDBApplication.Commands.ChildrenDetails
{
    public class CreateChildrenDetailsCommandHandler : IRequestHandler<CreateChildrenDetailsCommand, Response<string>>
    {
        private readonly IChildrenDetailsRepository _ChildrenDetailsRepository; 
        private readonly IMapper _mapper;

        public CreateChildrenDetailsCommandHandler(IChildrenDetailsRepository ChildrenDetailsRepository,
            IMapper mapper)
        {
            _ChildrenDetailsRepository = ChildrenDetailsRepository;            
            _mapper = mapper;
        }

        public async Task<Response<string>> Handle(CreateChildrenDetailsCommand request, CancellationToken cancellationToken)
        {
            var response = new Response<string>();
            try
            { 
                var _ChildrenDetail = _mapper.Map<ChildrenDetail>(request);

                _ChildrenDetailsRepository.Add(_ChildrenDetail);
                await _ChildrenDetailsRepository.UnitOfWork.SaveChangesAsync(cancellationToken); 
                response.Succeeded = true;
                response.StatusCode = (int)HttpStatusCode.Created;
                response.Message = "Children Details Added Successfull";
            }
            catch (Exception ex)
            {
                response.Succeeded = false;
                response.StatusCode = (int)HttpStatusCode.BadRequest;
                response.Message = "Error";
            }
            return response;
        } 
    }
}