﻿using AutoMapper;
using EDBApplication.Responses;
using EDBDomain.AggregateModels.ChildrenDetailAggregate;
using EDBDomain.IRepositories;
using MediatR; 
using System.Net;

namespace EDBApplication.Commands.ChildrenDetails
{
    public class UpdateChildrenDetailsCommandHandler : IRequestHandler<UpdateChildrenDetailsCommand, Response<string>>
    {
        private readonly IChildrenDetailsRepository _childrenDetailsRepository;
        private readonly IMapper _mapper;
        public UpdateChildrenDetailsCommandHandler(IChildrenDetailsRepository childrenDetailsRepository,
            IMapper mapper)
        {
            _childrenDetailsRepository = childrenDetailsRepository;
            _mapper = mapper;
        }
        public async Task<Response<string>> Handle(UpdateChildrenDetailsCommand request, CancellationToken cancellationToken)
        {
            var response = new Response<string>();
            try
            {
                var _request = _mapper.Map<ChildrenDetail>(request);
                this._childrenDetailsRepository.Update(_request);
                await this._childrenDetailsRepository.UnitOfWork.UpdateRecordAsync(cancellationToken);
                return new Response<string>()
                {
                    Succeeded = true,
                    Message = "Children Details Edited Successfully"
                };
            }
            catch (Exception ex)
            {
                response.Succeeded = false;
                response.StatusCode = (int)HttpStatusCode.BadRequest;
                response.Message = "Error";
            }
            return response;
        }
    }
}
