﻿
using EDBApplication.Responses;
using EDBDomain.AggregateModels.ParentsDetailAggregate;
using MediatR;
using System.Text.Json.Serialization;
 

namespace EDBApplication.Commands.ChildrenDetails
{
    public class DeleteChildrenDetailsCommand : IRequest<Response<string>>
    { 
        public Int64 childid { get; set; } 
    }
}
