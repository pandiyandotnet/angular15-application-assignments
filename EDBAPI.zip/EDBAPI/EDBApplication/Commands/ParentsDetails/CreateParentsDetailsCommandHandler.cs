﻿using AutoMapper;
using EDBApplication.Commands.ParentsDetails;
using EDBApplication.Responses;
using EDBDomain.AggregateModels.ParentsDetailAggregate;
using EDBDomain.IRepositories;
using MediatR; 
using System.Globalization;
using System.Net;

namespace EDBApplication.Commands.ParentsDetails
{
    public class CreateParentsDetailsCommandHandler : IRequestHandler<CreateParentsDetailsCommand, Response<string>>
    {
        private readonly IParentsDetailsRepository _parentsDetailsRepository; 
        private readonly IMapper _mapper;

        public CreateParentsDetailsCommandHandler(IParentsDetailsRepository parentsDetailsRepository,
            IMapper mapper)
        {
            _parentsDetailsRepository = parentsDetailsRepository;            
            _mapper = mapper;
        }

        public async Task<Response<string>> Handle(CreateParentsDetailsCommand request, CancellationToken cancellationToken)
        {
            var response = new Response<string>();
            try
            { 
                var _parentsDetail = _mapper.Map<ParentsDetail>(request);

                _parentsDetailsRepository.Add(_parentsDetail);
                await _parentsDetailsRepository.UnitOfWork.SaveChangesAsync(cancellationToken); 
                response.Succeeded = true;
                response.StatusCode = (int)HttpStatusCode.Created;
                response.Message = "Parents Details Added Successfull";
            }
            catch (Exception ex)
            {
                response.Succeeded = false;
                response.StatusCode = (int)HttpStatusCode.BadRequest;
                response.Message = "Error";
            }
            return response;
        } 
    }
}