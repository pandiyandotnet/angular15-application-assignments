﻿using AutoMapper;
using EDBApplication.Responses;
using EDBDomain.AggregateModels.ParentsDetailAggregate;
using EDBDomain.IRepositories;
using MediatR; 
using System.Net;

namespace EDBApplication.Commands.ParentsDetails
{
    public class UpdateParentsDetailsCommandHandler : IRequestHandler<UpdateParentsDetailsCommand, Response<string>>
    {
        private readonly IParentsDetailsRepository _parentsDetailsRepository;
        private readonly IMapper _mapper;
        public UpdateParentsDetailsCommandHandler(IParentsDetailsRepository parentsDetailsRepository,
            IMapper mapper)
        {
            _parentsDetailsRepository = parentsDetailsRepository;
            _mapper = mapper;
        }
        public async Task<Response<string>> Handle(UpdateParentsDetailsCommand request, CancellationToken cancellationToken)
        {
            var response = new Response<string>();
            try
            {
                var _request = _mapper.Map<ParentsDetail>(request);
                this._parentsDetailsRepository.Update(_request);
                await this._parentsDetailsRepository.UnitOfWork.UpdateRecordAsync(cancellationToken);
                return new Response<string>()
                {
                    Succeeded = true,
                    Message = "Parents Details Edited Successfully"
                };
            }
            catch (Exception ex)
            {
                response.Succeeded = false;
                response.StatusCode = (int)HttpStatusCode.BadRequest;
                response.Message = "Error";
            }
            return response;
        }
    }
}
