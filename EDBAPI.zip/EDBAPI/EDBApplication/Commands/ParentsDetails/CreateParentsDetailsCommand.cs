﻿using EDBApplication.Responses;
using MediatR; 
namespace EDBApplication.Commands.ParentsDetails
{
    public class CreateParentsDetailsCommand : IRequest<Response<string>>
    {
        public string username { get; set; }
        public string password { get; set; }
        public string gender { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string email { get; set; }
        public string mobile { get; set; }
        public string emiratesid { get; set; }
    }
}
