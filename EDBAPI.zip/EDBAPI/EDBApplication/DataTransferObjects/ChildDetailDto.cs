﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks; 
namespace EDBApplication.AggregateModels
{
    public class ChildDetailDto
    {
        public Int64 childid { get; set; }
        public Int64 parentid { get; set; } 
        public string gender { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public int age { get; set; } 
    }
}
