﻿using EDBDomain.AggregateModels.ChildrenDetailAggregate;
using EDBDomain.AggregateModels.ParentsDetailAggregate;
using EDBDomain.IRepositories;
using EDBDomain.SeedWork;
using EDBInfrastructure.DBContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDBInfrastructure.Repository
{
    public class ChildrenDetailsRepository : IChildrenDetailsRepository
    {
        private readonly ChildrenDbContext unitofWork;
        public IUnitOfWork UnitOfWork
        {
            get
            {
                return unitofWork;
            }
        }

        public ChildrenDetailsRepository(ChildrenDbContext context)
        {
            this.unitofWork = context ?? throw new ArgumentNullException(nameof(context));
        }

        public ChildrenDetail Add(ChildrenDetail childrenDetail)
        {
            return Manage(childrenDetail);
        }
        public ChildrenDetail Update(ChildrenDetail childrenDetail)
        {
            if (childrenDetail != null)
            {
                this.unitofWork.childrenDetail = childrenDetail;
            }
            return this.unitofWork.childrenDetail;
        }

        public ChildrenDetail Delete(ChildrenDetail childrenDetail)
        {
            return Manage(childrenDetail);
        }

        private ChildrenDetail Manage(ChildrenDetail childrenDetail)
        {
            this.unitofWork.childrenDetail = childrenDetail;
            return this.unitofWork.childrenDetail;
        }
    }
}
