﻿using EDBDomain.AggregateModels.ParentsDetailAggregate;
using EDBDomain.IRepositories;
using EDBDomain.SeedWork;
using EDBInfrastructure.DBContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDBInfrastructure.Repository
{
    public class ParentsDetailsRepository : IParentsDetailsRepository
    {
        private readonly ParentsDbContext unitofWork;
        public IUnitOfWork UnitOfWork
        {
            get
            {
                return unitofWork;
            }
        }

        public ParentsDetailsRepository(ParentsDbContext context)
        {
            this.unitofWork = context ?? throw new ArgumentNullException(nameof(context));
        }

        public ParentsDetail Add(ParentsDetail parentsDetail)
        {
            return Manage(parentsDetail);
        }
        public ParentsDetail Update(ParentsDetail publishQuizDetail)
        {
            if (publishQuizDetail != null)
            {
                this.unitofWork.parentsDetail = publishQuizDetail;
            }
            return this.unitofWork.parentsDetail;
        }

        public ParentsDetail Delete(ParentsDetail publishQuizDetail)
        {
            return Manage(publishQuizDetail);
        }

        private ParentsDetail Manage(ParentsDetail parentsDetail)
        {
            this.unitofWork.parentsDetail = parentsDetail;
            return this.unitofWork.parentsDetail;
        }
    }
}
