﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using EDBInfrastructure.Database;
using EDBDomain.AggregateModels.ChildrenDetailAggregate;
using EDBDomain.SeedWork; 
using System.Data.SqlClient;
using System.Data;
using System.Transactions;

namespace EDBInfrastructure.DBContext
{
    public class ChildrenDbContext : IDBContext, IUnitOfWork
    {
        private readonly ISqlConnectionFactory sqlConnectionFactory; 
        private readonly IConfiguration _configuration; 
        private bool disposedValue = false;
        public ChildrenDetail childrenDetail { get; set; }
        private int result = 0; 

        public ChildrenDbContext(ISqlConnectionFactory sqlConnectionFactory, IConfiguration configuration)
        {
            this.sqlConnectionFactory = sqlConnectionFactory; 
            this._configuration = configuration;
             
        } 
         
        public async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            using (var _conn = this.sqlConnectionFactory.GetOpenConnection())
            { 
                using (var tr = _conn.BeginTransaction())
                {
                    try
                    { 
                        using (SqlCommand command = new SqlCommand())
                        {
                            command.Connection = _conn;
                            command.CommandType = CommandType.StoredProcedure;                           
                            command.CommandText = "uspChildrenDataManagement";
                            command.Transaction = tr;
                            command.Parameters.Add("@parentid", SqlDbType.BigInt).Value = childrenDetail.parentid; 
                            command.Parameters.Add("@gender", SqlDbType.NVarChar).Value = childrenDetail.gender;
                            command.Parameters.Add("@firstname", SqlDbType.NVarChar).Value = childrenDetail.firstname;
                            command.Parameters.Add("@lastname", SqlDbType.NVarChar).Value = childrenDetail.lastname;
                            command.Parameters.Add("@age", SqlDbType.Int).Value = childrenDetail.age; 
                           
                            int result = command.ExecuteNonQuery();
                            if (1 != result)
                            {
                                throw (new Exception("Failed to update record in database. Unknown error"));
                            }
                        }
                        tr.Commit();
                        return result;
                    }
                    catch (Exception ex)
                    {
                        tr.Rollback(); 
                        return result;
                    }
                }
            }
        }
        public async Task<int> UpdateRecordAsync(CancellationToken cancellationToken = default(CancellationToken))
        {
            using (var _conn = this.sqlConnectionFactory.GetOpenConnection())
            {
                using (var tr = _conn.BeginTransaction())
                {
                    try
                    {
                        using (SqlCommand command = new SqlCommand())
                        {
                            command.Connection = _conn;
                            command.CommandType = CommandType.StoredProcedure;
                            command.CommandText = "uspChildrenDataManagement";
                            command.Transaction = tr;
                            command.Parameters.Add("@childid", SqlDbType.BigInt).Value = childrenDetail.childid;
                            command.Parameters.Add("@gender", SqlDbType.NVarChar).Value = childrenDetail.gender;
                            command.Parameters.Add("@firstname", SqlDbType.NVarChar).Value = childrenDetail.firstname;
                            command.Parameters.Add("@lastname", SqlDbType.NVarChar).Value = childrenDetail.lastname;
                            command.Parameters.Add("@age", SqlDbType.Int).Value = childrenDetail.age;
                            command.Parameters.Add("@action", SqlDbType.Int).Value = 1;

                            int result = command.ExecuteNonQuery();
                            if (1 != result)
                            {
                                throw (new Exception("Failed to update record in database. Unknown error"));
                            }
                        }
                        tr.Commit();
                        return result;
                    }
                    catch (Exception ex)
                    {
                        tr.Rollback();
                        return result;
                    }
                }
            }
        }
        public void Dispose()
        {
            this.Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        public Task<List<Guid>> SaveEntitiesAsync(CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }
        public async Task<int> DeleteRecordAsync(CancellationToken cancellationToken = default)
        {
            using (var _conn = this.sqlConnectionFactory.GetOpenConnection())
            {
                using (var tr = _conn.BeginTransaction())
                {
                    try
                    {
                        using (SqlCommand command = new SqlCommand())
                        {
                            command.Connection = _conn;
                            command.CommandType = CommandType.StoredProcedure;
                            command.CommandText = "uspChildrenDataManagement";
                            command.Transaction = tr;
                            command.Parameters.Add("@childid", SqlDbType.BigInt).Value = childrenDetail.childid; 
                            command.Parameters.Add("@action", SqlDbType.Int).Value = 2;

                            int result = command.ExecuteNonQuery();
                            if (1 != result)
                            {
                                throw (new Exception("Failed to update record in database. Unknown error"));
                            }
                        }
                        tr.Commit();
                        return result;
                    }
                    catch (Exception ex)
                    {
                        tr.Rollback();
                        return result;
                    }
                }
            }
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposedValue)
            {
                if (disposing)
                {
                    //dispose managed state (managed objects).
                }  
                this.disposedValue = true;
            } 
        }
        public Task<bool> UpdateEntitiesAsync(CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }
    }
}