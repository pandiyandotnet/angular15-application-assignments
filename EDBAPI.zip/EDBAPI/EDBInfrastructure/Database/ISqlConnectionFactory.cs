﻿using System.Data;
using System.Data.SqlClient;

namespace EDBInfrastructure.Database
{
    public interface ISqlConnectionFactory
    {
        SqlConnection GetOpenConnection();
    }
}
