﻿namespace EDBInfrastructure
{
    public class Class1
    {

    }
}