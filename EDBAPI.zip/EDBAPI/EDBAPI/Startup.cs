﻿using Autofac;
using System.Reflection;
using EDBInfrastructure.Database;
using EDBApplication.Processing;
using Autofac.Core;
using EDBAPI.AppStart;
using EDBApplication.AutoMapper;
using MediatR;
using EDBInfrastructure.DBContext;

namespace EDBAPI
{
    public class Startup
    {
        private const string connectionString = "SQLDbSettings:defaultConnectionString"; 
        readonly string MyAllowSpecificOrigins = "_myAllowSpecificOrigins";
        public IConfiguration Configuration { get; }
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        } 

        public void ConfigureContainer(ContainerBuilder builder)
        { 
            var connectionStringValue = Configuration.GetSection(connectionString).Value;
            
            builder.RegisterModule(new DataAccessModule(connectionStringValue));
            builder.RegisterModule(new MediatorModule());
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc(config =>
            {
                config.EnableEndpointRouting = false;
            });
            services.RegisterApplicationServices(Configuration);
            services.AddCors(options => options.AddPolicy("ApiCorsPolicy", builder =>
            {
                builder.WithOrigins("http://localhost:4200").AllowAnyMethod().AllowAnyHeader();
            }));
            services.AddMvc();
            services.AddSwaggerGen();
            services.AddAutoMapper(typeof(AutoMapperProfile)); 
            services.AddHealthChecks();
            services.AddOptions(); 
            services.AddMediatR(AppDomain.CurrentDomain.GetAssemblies());
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            } 

            if (env.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            } 
            app.UseRouting(); 
            app.UseHttpsRedirection();
            app.UseCors("ApiCorsPolicy");
            app.UseMvc();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
