﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
 

namespace EDBAPI.Controllers
{  
    [ApiController]
    public class BaseController : ControllerBase
    {
        
    }
}
