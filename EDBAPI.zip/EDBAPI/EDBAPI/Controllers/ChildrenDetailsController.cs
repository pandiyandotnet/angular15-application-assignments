﻿using EDBApplication.AggregateModels;
using EDBApplication.Commands.ChildrenDetails;
using EDBApplication.Queries.GetChildDetails;
using EDBApplication.Queries.GetParentDetails;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace EDBAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ChildrenDetailsController : BaseController
    {
        private readonly IMediator _mediator;
        public ChildrenDetailsController(IMediator mediator)
        {
            _mediator = mediator;
        }

        #region Children Details

        /// <summary>
        /// To get child details.
        /// </summary>  
        /// <param name="parentid">parentid</param> 
        /// <returns></returns>
        [HttpGet("{parentid}")]
        [ProducesResponseType(typeof(List<ChildDetailDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetChildDetails(int parentid)
        {
            var res = await _mediator.Send(new GetChildDetailsQuery() { parentid = parentid });
            if (res != null)
            {
                return Ok(res);
            }
            else
            {
                return Problem("Result not found", null, StatusCodes.Status404NotFound);
            }
        }


        /// <summary>
        /// To create Children Details
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Guid), StatusCodes.Status201Created)]
        public async Task<IActionResult> CreateChildrenDetails(CreateChildrenDetailsCommand request)
        {
            var reportTypeResponse = await _mediator.Send(request);
            return Ok(reportTypeResponse);
        }

        /// <summary>
        /// To update Children Details by Id
        /// </summary>
        /// <param name="request"></param>
        /// <param name="id">Unique Identifier</param>
        /// <returns></returns> 
        [HttpPut("{childid}")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Guid), StatusCodes.Status204NoContent)]

        public async Task<IActionResult> UpdateChildrenDetailsById(UpdateChildrenDetailsCommand request, int childid)
        {
            request.childid = childid;
            var result = await _mediator.Send(request);
            return Ok(result);
        }

        /// <summary>
        /// To delete Children Details by Id
        /// </summary>
        /// <param name="request"></param>
        /// <param name="id">Unique Identifier</param>
        /// <returns></returns> 
        [HttpPut("Delete/{childid}")]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Guid), StatusCodes.Status204NoContent)]

        public async Task<IActionResult> DeleteChildrenDetailsById(DeleteChildrenDetailsCommand request, int childid)
        {
            request.childid = childid;
            var result = await _mediator.Send(request);
            return Ok(result);
        }
        #endregion
    }
}
