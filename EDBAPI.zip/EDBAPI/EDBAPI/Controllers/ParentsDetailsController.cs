﻿using EDBApplication.AggregateModels;
using EDBApplication.Commands.ParentsDetails;
using EDBApplication.Queries.GetLogin;
using EDBApplication.Queries.GetParentDetails;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace EDBAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ParentsDetailsController : BaseController
    {
        private readonly IMediator _mediator;
        public ParentsDetailsController(IMediator mediator)
        {
            _mediator = mediator;
        }

        #region Login
        /// <summary>
        /// To get login details.
        /// </summary>  
        /// <param name="username">username</param>
        /// <param name="password">password</param>
        /// <returns></returns>
        [HttpGet("{username}/{password}")]
        [ProducesResponseType(typeof(int), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> login(string username, string password)
        {
            var res = await _mediator.Send(new GetLoginQuery() { username = username, password = password });
            if (res!=0)
            {
                return Ok(res);
            }
            else
            {
                return Problem("Result not found", null, StatusCodes.Status404NotFound);
            }
        }

        #endregion

        #region Parents Details 

        /// <summary>
        /// To get parent details.
        /// </summary>  
        /// <param name="parentid">parentid</param> 
        /// <returns></returns>
        [HttpGet("{parentid}")]
        [ProducesResponseType(typeof(List<ParentsDetailDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetParentDetails(int parentid)
        {
            var res = await _mediator.Send(new GetParentDetailsQuery() { parentid = parentid });
            if (res != null)
            {
                return Ok(res);
            }
            else
            {
                return Problem("Result not found", null, StatusCodes.Status404NotFound);
            }
        }

        /// <summary>
        /// To create Parents Details
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Guid), StatusCodes.Status201Created)]
        public async Task<IActionResult> CreateParentsDetails(CreateParentsDetailsCommand request)
        {
            var reportTypeResponse = await _mediator.Send(request);
            return Ok(reportTypeResponse);
        }

        ///// <summary>
        ///// To update Parents Details by Id
        ///// </summary>
        ///// <param name="request"></param>
        ///// <param name="id">Unique Identifier of report type</param>
        ///// <returns></returns> 
        //[HttpPut("{id}")]
        //[ProducesResponseType(StatusCodes.Status400BadRequest)]
        //[ProducesResponseType(typeof(Guid), StatusCodes.Status204NoContent)]

        //public async Task<IActionResult> UpdateParentsDetailsById(UpdateReportTypeCommand request, Guid id)
        //{
        //    request.id = id;
        //    var result = await _mediator.Send(request);
        //    return Ok(result);
        //}  
        #endregion 
    }
}
