﻿namespace EDBAPI.Constants
{
    public class ApiConstant
    {
        public const string CorsPolicy = "EDB.CorsPolicy";
    }
}
