﻿using EDBApplication.Commands.ChildrenDetails;
using EDBApplication.Commands.ParentsDetails;
using EDBDomain.IRepositories;
using EDBInfrastructure.DBContext;
using EDBInfrastructure.Repository;
using Microsoft.Extensions.Http; 
namespace EDBAPI.AppStart
{
    public static class ApplicationServices
    {
        public static void RegisterApplicationServices(this IServiceCollection services, IConfiguration configuration)
        {
            RegisterServices(services);  
        }
         
        private static void RegisterServices(IServiceCollection services)
        {
            services.AddTransient(typeof(CreateParentsDetailsCommand), typeof(CreateParentsDetailsCommand));
            services.AddTransient(typeof(IParentsDetailsRepository), typeof(ParentsDetailsRepository));
            services.AddScoped(typeof(ParentsDbContext), typeof(ParentsDbContext));

            services.AddTransient(typeof(CreateChildrenDetailsCommand), typeof(CreateChildrenDetailsCommand));
            services.AddTransient(typeof(DeleteChildrenDetailsCommand), typeof(DeleteChildrenDetailsCommand));
            services.AddTransient(typeof(IChildrenDetailsRepository), typeof(ChildrenDetailsRepository));
            services.AddScoped(typeof(ChildrenDbContext), typeof(ChildrenDbContext));
        } 
    }
}
